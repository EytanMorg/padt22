#Program to calculate md5 hash for single string or file with multiple strings.

#Import hashlib to calculate md5 hash later
import hashlib

#Function which opens file and hashes every word found in the file
def filecalculate(filename):
    #Opens file called filename (mode = read is optional, default is read)
    file = open(filename, "r")
    #For every word found in the file
    for i in (file.read().split()):
        #Make x the string value of the word
        x = str(i)
        #Print the md5 hash for x
        print(hashlib.md5(x.encode()).hexdigest(), " is the MD5 hash for ", x)

#Function which hashes a single string
def singlestringcalculate(singlestring):
    #Print the md5 hash for singlestring
    print(hashlib.md5(singlestring.encode()).hexdigest(), "is the MD5 hash for", singlestring)

#Display the options for the user
print("Do you want to calculate the MD5 hash for a single string or a text file containing multiple strings?")
print("[1] I want to enter a single string to calculate the MD5 hash")
print("[2] I want to enter a text file containing multiple strings to calculate the MD5 hash")

#Get users requested option
ask = int(input("Enter 1 or 2: "))

#If user requests 1, ask to input a string and call the singlestringcalculate function with it
if ask == 1:
    tohash = input("Enter the string you want to calculate an hash for: ")
    singlestringcalculate(tohash)

#If user requests 2, display how the structure of the file has to be, where it has to be and how to enter the name
elif ask == 2:
    print("Make sure that every string you want to hash is seperated with a line break!")
    print("Make sure the file is in the same directory as the Python program!")
    #Get filename
    filetohash = input('Enter the filename and extension, for example "file.txt": ')
    #Call the filecalculate function with the filename
    filecalculate(filetohash)