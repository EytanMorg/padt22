
import sys
import time

def slowprint(s):
    for c in s + '\n':
        sys.stdout.write(c)
        sys.stdout.flush()
        time.sleep(1./100)
#Create a dict with each letter as key with the corresponding morsecode

AlphabetMorse = {'A': '.-', 'B': '-...', 'C': '-.-.', 'D': '-..', 'E': '.', 'F': '..-.', 'G': '--.'
                 , 'H': '....', 'I': '..', 'J': '.---', 'K': '-.-', 'L': '.-..', 'M':'--', 'N': '-.',
                 'O':'---', 'P': '.--.', 'Q': '--.-','R': '.-.', 'S': '...', 'T': '-',
                 'U': '..-', 'V': '...-', 'W': '.--', 'X': '-..-', 'Y': '-.--','Z': '--..'}

decrypterlistA = {'.-':'A', '-...': 'B', '-.-.': 'C', '-..': 'D', '.':'E', '..-.': 'F', '--.':'G',
                  '....': 'H', '..':'I', '.---':'J', '-.-':'K', '.-..':'L', '--':'M','-.':'N', '---':'O',
                  '.--.':'P','--.-':'Q', '.-.':'R', '...':'S', '-':'T', '..-':'U', '...-':'V', '.--':'W', '-..-':'X',
                  '-.--':'Y', '--..':'Z'}



print('A guide of how to use this converter:\n ')
print('First import this code in to the terminal, by doing: from import Morse *\n')
print('If it does not work then: \n')
print('--------------------------------------')
slowprint('....................../´¯/)')
slowprint('....................,/¯../')
slowprint('.................../..../ ')
slowprint("............./´¯/'...'/´¯¯`·¸")
slowprint("........../'/.../..../......./¨¯\ ")
slowprint("........('(...´...´.... ¯~/'...') ")
slowprint(".........\.................'...../ ")
slowprint("..........''...\.......... _.·´ ")
slowprint("............\..............( ")
slowprint("..............\.............\...\n")

slowprint('To convert from text to Morse use this command: ')
slowprint('morse("TEXT IN CAPS")\n')
slowprint("To convert from morse to text use: ")
slowprint("decrypt()\n")
slowprint("Note that each morse code character must be seperated with spaces!")

#Create a function which looks at the dictionary and adds the corresponding morse code
#Seperate each letter with spaces to seperate morse codes for different characters



def morse(message):
    #Create empty string
    String = ''

    for x in message:
        if x != ' ':
            #add each letter with the corresponding morsecode to each other for 1 beautiful sentence
            #Seperate each Morse letter from each other so it is more readable
            String += AlphabetMorse[x] + ' '

        else:
            #Each space represents different characters
            #Two spaces represents different words
            String += ' '

    return String

def decrypt(mcode):
    return ''.join(decrypterlistA.get(i) for i in mcode.split())





#function to run the program

def main():
    if __name__ == '__main__':

        main()


