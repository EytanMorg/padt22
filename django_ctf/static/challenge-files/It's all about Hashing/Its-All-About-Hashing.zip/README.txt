In this challenge you (a team of hackers) are trying to access a secured directory in the database of a fictional company called BlueGen Inc.

The objective is to capture a text file containing confidential information (the flag).

Your colleagues have managed to get some information about the company's login system giving you an idea on how to log in, managed to breach the database and
capture a section of hashed login credentials and they have been able to phish some users including some admins of the website.

This is what we know so far:
	* The website requires you to login with your username/email address and your password combined together. For example: userpassword
	* The company doesn't store the login credentials in plaintext. They only store the hashes.
	* It is unclear what hashing algorithm is being used for the login credentials
	* Only admins can access the file we need
	* Admins can't acces the MasterPassword immediately. They first have to log in with a regular account and proceed on logging in with an admin account afterwards.
	* The admin zip can be accessed with the right usernamepassword combination
	* Some of the hashed credentials could be outdated since we breached it a while ago
	* Check out hasher.py
Goodluck!
