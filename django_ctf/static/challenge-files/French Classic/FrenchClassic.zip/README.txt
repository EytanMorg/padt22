How to find the answer.
It could be everywhere, really.
Sometimes it’s in the simplest things.

But sometimes it’s not that simple.
If you just don’t see it, you don’t see it.
Right in front of you, maybe.
That’s why you should take your time.
How long, depends on the person.
Perhaps it may take a hour.
Listen to the ticking clock.
And then suddenly the time feels slower.
Can’t you feel it become slower?
Eventually it will feel fast again.

