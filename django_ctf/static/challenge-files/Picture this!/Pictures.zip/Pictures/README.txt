In 1 van deze afbeeldingen is een ander bestand verstopt.

"Ik vraag me wel altijd af of de Mona Lisa mij wat raad weet te geven"
